// swift-tools-version: 5.9
import PackageDescription
import AppleProductTypes
let package = Package(
    name: "FrameFitLaunchCheck",
    platforms: [.iOS("17.0")],
    products: [.iOSApplication(name: "프레임핏 실행 점검", targets: ["LaunchCheck"], bundleIdentifier: "local.framefit.launchcheck", displayVersion: "1.0", bundleVersion: "1", appIcon: .placeholder(icon: .camera), accentColor: .presetColor(.teal), supportedDeviceFamilies: [.pad], supportedInterfaceOrientations: [.portrait, .landscapeLeft, .landscapeRight])],
    targets: [.executableTarget(name: "LaunchCheck", path: "Sources")]
)
