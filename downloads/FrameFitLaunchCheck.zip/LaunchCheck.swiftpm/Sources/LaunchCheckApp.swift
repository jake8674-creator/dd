import SwiftUI

@main struct LaunchCheckApp: App {
    var body: some Scene {
        WindowGroup { LaunchCheckView() }
    }
}

struct LaunchCheckView: View {
    @State private var text = ""
    var body: some View {
        VStack(spacing: 24) {
            Text("프레임핏 실행 점검").font(.title)
            Text("이 화면이 보이면 기본 앱 빌드와 실행이 가능합니다.")
            TextField("여기에 테스트를 입력하세요", text: $text)
                .textFieldStyle(.roundedBorder)
            Text("입력: \(text)")
        }
        .padding(32)
    }
}
