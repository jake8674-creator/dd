import XCTest
@testable import FrameFitCore

final class MeasurementTests:XCTestCase {
    func fixture(_ kind:ViewKind = .front)->Fitting {
        var s=Fitting();s.a="50";s.dbl="20"
        var p=PhotoRecord(kind:kind,filename:"test.jpg",width:1200,height:800,flashFired:true,confirmed:true,poseConfirmed:true)
        let pixels:[Anchor:Vec]=[.outerR:Vec(x:100,y:400),.innerR:Vec(x:516.6666666667,y:400),.innerL:Vec(x:683.3333333333,y:400),.outerL:Vec(x:1100,y:400),.pupilR:Vec(x:350,y:400),.pupilL:Vec(x:850,y:400),.upperR:Vec(x:350,y:200),.lowerR:Vec(x:350,y:600),.upperL:Vec(x:850,y:200),.lowerL:Vec(x:850,y:600)]
        for (key,v) in pixels{p.marks[key.rawValue]=Mark(point:Vec(x:v.x/p.width,y:v.y/p.height),automatic:false)}
        s.photos[kind.rawValue]=p;return s
    }
    func sideFixture(_ kind:ViewKind = .right,angle:Double=10)->Fitting {
        var s=Fitting();s.side=kind
        var p=PhotoRecord(kind:kind,filename:"side.jpg",width:1000,height:800,gravity:Vec(x:0,y:1),flashFired:true,confirmed:true,poseConfirmed:true)
        let dx=200*tan(angle*Double.pi/180)
        let pixels:[Anchor:Vec]=[.backTop:Vec(x:550+dx,y:200),.backBottom:Vec(x:550-dx,y:600),.cornea:Vec(x:500,y:400)]
        for (key,v) in pixels{p.marks[key.rawValue]=Mark(point:Vec(x:kind == .left ? 1-v.x/1000 : v.x/1000,y:v.y/800),automatic:false)}
        s.photos[kind.rawValue]=p;return s
    }
    func testKnownPDAndHeight(){let values=Measure.front(fixture(),.front);XCTAssertEqual(values[0].value!,60,accuracy:1e-8);XCTAssertEqual(values[1].value!,30,accuracy:1e-8);XCTAssertEqual(values[2].value!,30,accuracy:1e-8);XCTAssertEqual(values[3].value!,24,accuracy:1e-8);XCTAssertEqual(values[4].value!,24,accuracy:1e-8)}
    func testNearIsIndependent(){var s=fixture();var near=fixture(.near).photos["near"]!;near.marks["pupilR"]!.point.x=375/1200;near.marks["pupilL"]!.point.x=825/1200;near.flashFired=false;s.photos["near"]=near;XCTAssertEqual(Measure.front(s,.near)[0].value!,54,accuracy:1e-8);XCTAssertEqual(Measure.front(s,.front)[0].value!,60,accuracy:1e-8)}
    func testMissingPhoto(){XCTAssertTrue(Measure.front(Fitting(),.front).allSatisfy{$0.value==nil})}
    func testNoScale(){var s=fixture();s.a="";XCTAssertTrue(Measure.front(s,.front).allSatisfy{$0.value==nil})}
    func testNoConfirmation(){var s=fixture();s.photos["front"]!.confirmed=false;XCTAssertNil(Measure.front(s,.front)[0].value)}
    func testNoPoseConfirmation(){var s=fixture();s.photos["front"]!.poseConfirmed=false;XCTAssertNil(Measure.front(s,.front)[0].value)}
    func testMissingRearFlash(){var s=fixture();s.photos["front"]!.flashFired=false;XCTAssertNil(Measure.front(s,.front)[0].value)}
    func testMissingPoint(){var s=fixture();s.photos["front"]!.marks.removeValue(forKey:"innerR");XCTAssertNil(Measure.front(s,.front)[0].value)}
    func testOutOfBounds(){var s=fixture();s.photos["front"]!.marks["pupilR"]!.point.x = -0.1;XCTAssertNil(Measure.front(s,.front)[0].value)}
    func testNonFiniteCoordinates(){var s=fixture();s.photos["front"]!.marks["pupilR"]!.point.x = .nan;XCTAssertNil(Measure.front(s,.front)[0].value)}
    func testNonFiniteDimensions(){var s=fixture();s.photos["front"]!.width = .infinity;XCTAssertNil(Measure.front(s,.front)[0].value)}
    func testReversedBoundary(){var s=fixture();s.photos["front"]!.marks["innerR"]!.point.x=0.01;XCTAssertNil(Measure.front(s,.front)[0].value)}
    func testAsymmetricLenses(){var s=fixture();s.photos["front"]!.marks["innerR"]!.point.x=0.3;XCTAssertNil(Measure.front(s,.front)[0].value)}
    func testWrongBridgeRatio(){var s=fixture();s.dbl="40";XCTAssertNil(Measure.front(s,.front)[0].value)}
    func testPupilOutsideLens(){var s=fixture();s.photos["front"]!.marks["pupilR"]!.point.x=0.5;XCTAssertNil(Measure.front(s,.front)[0].value)}
    func testPupilAboveLens(){var s=fixture();s.photos["front"]!.marks["pupilR"]!.point.y=0.1;XCTAssertNil(Measure.front(s,.front)[0].value)}
    func testGlintsDoNotChangePD(){var s=fixture();s.photos["front"]!.marks["glintR"]=Mark(point:Vec(x:0.4,y:0.5),automatic:true);s.photos["front"]!.marks["glintL"]=Mark(point:Vec(x:0.6,y:0.5),automatic:true);XCTAssertEqual(Measure.front(s,.front)[0].value!,60,accuracy:1e-8)}
    func testRotationInvariance(){var s=fixture();var p=s.photos["front"]!;let a=8.0*Double.pi/180;for key in Array(p.marks.keys){let old=p.marks[key]!.point;let x=old.x*p.width-600,y=old.y*p.height-400;p.marks[key]!.point=Vec(x:(x*cos(a)-y*sin(a)+600)/p.width,y:(x*sin(a)+y*cos(a)+400)/p.height)};s.photos["front"]=p;XCTAssertEqual(Measure.front(s,.front)[0].value!,60,accuracy:1e-8);XCTAssertEqual(Measure.front(s,.front)[3].value!,24,accuracy:1e-8)}
    func testResolutionInvariance(){var s=fixture();s.photos["front"]!.width *= 2;s.photos["front"]!.height *= 2;XCTAssertEqual(Measure.front(s,.front)[0].value!,60,accuracy:1e-8)}
    func testRightTilt(){XCTAssertEqual(Measure.side(sideFixture())[0].value!,10,accuracy:1e-8)}
    func testLeftTilt(){XCTAssertEqual(Measure.side(sideFixture(.left))[0].value!,10,accuracy:1e-8)}
    func testNegativeTilt(){XCTAssertEqual(Measure.side(sideFixture(angle:-10))[0].value!,-10,accuracy:1e-8)}
    func testZeroTilt(){XCTAssertEqual(Measure.side(sideFixture(angle:0))[0].value!,0,accuracy:1e-8)}
    func testMissingGravity(){var s=sideFixture();s.photos["right"]!.gravity=nil;XCTAssertNil(Measure.side(s)[0].value)}
    func testNoInventedVertexDistance(){XCTAssertNil(Measure.side(sideFixture())[1].value)}
    func testTiltOutOfRange(){XCTAssertNil(Measure.side(sideFixture(angle:45))[0].value)}
    func testWrongSideNotCopied(){var s=sideFixture();s.side = .left;XCTAssertNil(Measure.side(s)[0].value)}
    func testWrap(){var s=Fitting();var p=PhotoRecord(kind:.top,filename:"top.jpg",width:1000,height:1000,flashFired:true,confirmed:true,poseConfirmed:true);let dy=0.3*tan(10*Double.pi/180);let points:[Anchor:Vec]=[.outerR:Vec(x:0.1,y:0.5),.innerR:Vec(x:0.4,y:0.5+dy),.innerL:Vec(x:0.6,y:0.5+dy),.outerL:Vec(x:0.9,y:0.5)];for(k,v) in points{p.marks[k.rawValue]=Mark(point:v,automatic:false)};s.photos["top"]=p;XCTAssertEqual(Measure.wrap(s)[0].value!,20,accuracy:1e-8);XCTAssertEqual(Measure.wrap(s)[1].value!,10,accuracy:1e-8)}
    func testJSONRoundtrip()throws{var s=fixture();s.name="한글 이름";s.notes="메모\n두 번째 줄";let data=try JSONEncoder().encode(s);let decoded=try JSONDecoder().decode(Fitting.self,from:data);XCTAssertEqual(decoded.name,s.name);XCTAssertEqual(decoded.notes,s.notes);XCTAssertEqual(decoded.photos["front"]!.marks["pupilR"]!.point,s.photos["front"]!.marks["pupilR"]!.point)}
    func testDraftDoesNotMutateOriginal(){let s=fixture();var draft=s;draft.name="수정";XCTAssertEqual(s.name,"");XCTAssertEqual(draft.photos.count,s.photos.count)}
    func testDecimalParsing(){XCTAssertEqual(Fitting.number(" 50,5 "),50.5);XCTAssertNil(Fitting.number("nan"));XCTAssertNil(Fitting.number("inf"))}
}
