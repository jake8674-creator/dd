import XCTest
@testable import FrameFitCore
final class LensCandidatesTests:XCTestCase {
    func oval(_ center:Vec,_ rx:Double=0.14,_ ry:Double=0.14)->[Vec]{(0...48).map{i in let t=Double(i)*2*Double.pi/48;return Vec(x:center.x+rx*cos(t),y:center.y+ry*sin(t))}}
    let eyes=[Vec(x:0.3,y:0.5),Vec(x:0.7,y:0.5)]
    func testPairFound(){let p=LensCandidates.pair(contours:eyes.map{oval($0)},eyes:eyes,aspect:1.5);XCTAssertNotNil(p);XCTAssertEqual(p!.right.left,0.16,accuracy:1e-8);XCTAssertEqual(p!.left.right,0.84,accuracy:1e-8)}
    func testRejectWholeFace(){XCTAssertNil(LensCandidates.pair(contours:[oval(Vec(x:0.5,y:0.5),0.4,0.45)],eyes:eyes,aspect:1.5))}
    func testRejectEyeSizeContours(){XCTAssertNil(LensCandidates.pair(contours:eyes.map{oval($0,0.04,0.02)},eyes:eyes,aspect:1.5))}
    func testNeedsBothLenses(){XCTAssertNil(LensCandidates.pair(contours:[oval(eyes[0])],eyes:eyes,aspect:1.5))}
    func testRejectOpenContours(){let contours=eyes.map{Array(oval($0).dropLast(10))};XCTAssertNil(LensCandidates.pair(contours:contours,eyes:eyes,aspect:1.5))}
    func testRejectOverlappingLenses(){XCTAssertNil(LensCandidates.pair(contours:eyes.map{oval($0,0.215,0.14)},eyes:eyes,aspect:1.5))}
    func testMissingEyes(){XCTAssertNil(LensCandidates.pair(contours:eyes.map{oval($0)},eyes:[],aspect:1.5))}
    func testEyeOrderDoesNotChangeSides(){let pair=LensCandidates.pair(contours:eyes.map{oval($0)},eyes:eyes.reversed(),aspect:1.5);XCTAssertEqual(pair!.right.center.x,0.3,accuracy:1e-8)}
    func testNonFiniteContourRejected(){var points=oval(eyes[0]);points[5].x = .nan;XCTAssertNil(LensCandidates.pair(contours:[points,oval(eyes[1])],eyes:eyes,aspect:1.5))}
    func testNonSquareImage(){let pair=LensCandidates.pair(contours:eyes.map{oval($0,0.14,0.07)},eyes:eyes,aspect:0.75);XCTAssertNotNil(pair)}
}
