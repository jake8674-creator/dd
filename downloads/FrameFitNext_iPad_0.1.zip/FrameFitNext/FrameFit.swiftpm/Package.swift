// swift-tools-version: 5.9
import PackageDescription
import AppleProductTypes
let package = Package(
    name: "FrameFitNext", platforms: [.iOS("17.0")],
    products: [.iOSApplication(name: "프레임핏 새로", targets: ["FrameFit"], bundleIdentifier: "local.framefit.next", displayVersion: "0.1.0", bundleVersion: "1", appIcon: .placeholder(icon: .camera), accentColor: .presetColor(.teal), supportedDeviceFamilies: [.pad], supportedInterfaceOrientations: [.portrait, .landscapeLeft, .landscapeRight], capabilities: [.camera(purposeString: "안경 착용 사진에서 눈과 렌즈 기준점을 확인합니다. 사진은 기기에만 저장됩니다.")], additionalInfoPlistContentFilePath: "AppInfo.plist")],
    targets: [.executableTarget(name: "FrameFit", path: "Sources")]
)
