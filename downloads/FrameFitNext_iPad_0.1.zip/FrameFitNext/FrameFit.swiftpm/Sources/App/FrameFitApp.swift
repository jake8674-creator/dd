import SwiftUI

@main struct FrameFitApp:App {
    @StateObject private var library=Library()
    var body:some Scene{WindowGroup{Home().environmentObject(library).tint(.mint).preferredColorScheme(.dark)}}
}
struct Home:View {
    @EnvironmentObject private var library:Library
    @State private var editing:Fitting?
    @State private var deleting:Fitting?
    var body:some View{
        NavigationStack{
            ScrollView{
                VStack(alignment:.leading,spacing:24){
                    Label("FRAMEFIT NEXT",systemImage:"eyeglasses").font(.headline).foregroundStyle(.mint)
                    Text("눈과 안경을,\n더 가까이 살펴보세요.").font(.system(size:40,weight:.bold,design:.rounded))
                    Text("지그 없이 촬영 · 기준점 직접 확인 · 기기 내 저장").foregroundStyle(.secondary)
                    Button{editing=Fitting()}label:{Label("새 피팅 시작",systemImage:"plus").frame(maxWidth:.infinity).padding(12)}.buttonStyle(.borderedProminent)
                    Text("사진에서 계산한 추정값입니다. 실제 측정기와 비교 검증 전이며 렌즈 주문 확정값으로 사용하지 마세요.").font(.callout).padding(18).background(.orange.opacity(0.12),in:RoundedRectangle(cornerRadius:16))
                    Text("저장한 피팅").font(.title2.bold())
                    if library.items.isEmpty{ContentUnavailableView("첫 피팅을 시작하세요",systemImage:"camera",description:Text("사진과 확인한 결과가 이 기기에 저장됩니다."))}
                    ForEach(library.items){f in
                        HStack{
                            Button{editing=f}label:{VStack(alignment:.leading,spacing:8){Text(f.title).font(.headline);Text(f.date,style:.date).font(.caption).foregroundStyle(.secondary);Text("사진 \(f.photos.count)장").font(.caption)}.frame(maxWidth:.infinity,alignment:.leading)}.buttonStyle(.plain)
                            Button(role:.destructive){deleting=f}label:{Image(systemName:"trash")}
                        }.padding(20).background(.white.opacity(0.06),in:RoundedRectangle(cornerRadius:16))
                    }
                    Text("NEXT 0.1 · M4 iPad Pro 대상 · 로그인 및 서버 전송 없음").font(.caption).foregroundStyle(.secondary)
                }.padding(28).frame(maxWidth:1000)
            }.frame(maxWidth:.infinity).background(Color(red:0.035,green:0.065,blue:0.085))
                .navigationTitle("프레임핏")
                .fullScreenCover(item:$editing){f in Workspace(fitting:f)}
                .confirmationDialog("기록과 사진을 삭제할까요?",isPresented:Binding(get:{deleting != nil},set:{if !$0{deleting=nil}})){Button("삭제",role:.destructive){if let f=deleting{do{try library.delete(f)}catch{library.problem=error.localizedDescription}};deleting=nil}}
                .alert("저장 상태",isPresented:Binding(get:{library.problem != nil},set:{if !$0{library.problem=nil}})){Button("확인"){library.problem=nil}}message:{Text(library.problem ?? "")}
        }
    }
}
struct Workspace:View {
    @EnvironmentObject private var library:Library
    @Environment(\.dismiss) private var dismiss
    @State var fitting:Fitting
    @State private var cameraKind:ViewKind?
    @State private var pending:PendingPhoto?
    @State private var review:PhotoRecord?
    @State private var basic=false
    @State private var processing=false
    @State private var error:String?
    @State private var exportFile:SharedFile?
    struct PendingPhoto {var exposure:Exposure;var kind:ViewKind}
    struct SharedFile:Identifiable {let id=UUID();let url:URL}
    var body:some View{
        NavigationStack{
            ScrollView{
                VStack(alignment:.leading,spacing:24){
                    HStack{VStack(alignment:.leading){Text(fitting.title).font(.largeTitle.bold());Text("A \(fitting.a.isEmpty ? "—" : fitting.a) mm  ·  DBL \(fitting.dbl.isEmpty ? "—" : fitting.dbl) mm").foregroundStyle(.secondary)};Spacer();Button("기본정보 입력"){basic=true}.buttonStyle(.borderedProminent)}
                    Picker("촬영할 측면",selection:Binding(get:{fitting.side},set:{side in var next=fitting;next.side=side;persist(next)})){Text("고객 오른쪽").tag(ViewKind.right);Text("고객 왼쪽").tag(ViewKind.left)}.pickerStyle(.segmented)
                    LazyVGrid(columns:[GridItem(.adaptive(minimum:300))],spacing:16){ForEach(fitting.kinds){kind in card(kind)}}
                    Text("확인한 측정값").font(.title2.bold())
                    ForEach(Measure.all(fitting)){r in HStack{VStack(alignment:.leading,spacing:6){Text(r.label).font(.headline);Text(r.reason).font(.caption).foregroundStyle(.secondary)};Spacer();Text(r.formatted).font(.title.monospacedDigit());Text(r.unit).foregroundStyle(.secondary)}.padding(.vertical,10);Divider()}
                    Text("PD는 동공 중심을 기준으로 합니다. 각막 반사 후보는 위치 확인용이며 PD 기준으로 자동 대체하지 않습니다. 정점간거리는 깊이 검증 전까지 제공하지 않습니다.").font(.caption).foregroundStyle(.secondary)
                    Button("CSV로 결과 내보내기"){do{exportFile=SharedFile(url:try library.export(fitting))}catch{self.error=error.localizedDescription}}.buttonStyle(.bordered)
                }.padding(24).frame(maxWidth:1100)
            }.frame(maxWidth:.infinity)
                .navigationTitle("피팅 작업").navigationBarTitleDisplayMode(.inline)
                .toolbar{ToolbarItem(placement:.cancellationAction){Button("목록"){do{try library.save(fitting);dismiss()}catch{self.error=error.localizedDescription}}}}
                .sheet(isPresented:$basic){BasicForm(initial:fitting){next in try library.save(next);fitting=next}}
                .fullScreenCover(item:$cameraKind,onDismiss:processPending){kind in CaptureScreen(kind:kind,nearCM:fitting.nearCM){exposure in pending=PendingPhoto(exposure:exposure,kind:kind);cameraKind=nil}}
                .fullScreenCover(item:$review){r in if let image=library.image(r){MarkerReview(image:image,record:r){edited in var next=fitting;next.photos[edited.kind.rawValue]=edited;try library.save(next);fitting=next}}else{ContentUnavailableView("사진을 읽지 못했습니다",systemImage:"photo.badge.exclamationmark").overlay(alignment:.topTrailing){Button("닫기"){review=nil}.padding()}}}
                .sheet(item:$exportFile){file in SharePanel(url:file.url)}
                .overlay{if processing{ZStack{Color.black.opacity(0.75).ignoresSafeArea();ProgressView("눈과 렌즈 윤곽 후보를 찾는 중…").padding(30).background(.regularMaterial,in:RoundedRectangle(cornerRadius:20))}}}
                .alert("확인",isPresented:Binding(get:{error != nil},set:{if !$0{error=nil}})){Button("확인"){error=nil}}message:{Text(error ?? "")}
        }.interactiveDismissDisabled()
    }
    private func card(_ kind:ViewKind)->some View{
        VStack(alignment:.leading,spacing:12){
            Text(kind.title).font(.title3.bold())
            if let p=fitting.photos[kind.rawValue],let image=library.image(p){Image(uiImage:image).resizable().scaledToFit().frame(height:170).frame(maxWidth:.infinity);Text(p.confirmed ? "기준점 확인 완료" : "기준점 확인 필요").font(.caption).foregroundStyle(p.confirmed ? .mint : .orange)}else{Image(systemName:kind == .top ? "arrow.down.viewfinder" : "person.crop.rectangle").font(.system(size:48)).frame(height:170).frame(maxWidth:.infinity).foregroundStyle(.secondary)}
            HStack{Button("촬영"){cameraKind=kind}.buttonStyle(.borderedProminent);if let p=fitting.photos[kind.rawValue]{Button("기준점 확인"){review=p}.buttonStyle(.bordered)}}
            Text(kind == .near ? "전면 카메라 · 흰 화면 플래시" : "후면 카메라 · LED 플래시").font(.caption).foregroundStyle(.secondary)
        }.padding(18).background(.white.opacity(0.06),in:RoundedRectangle(cornerRadius:20))
    }
    private func persist(_ next:Fitting){do{try library.save(next);fitting=next}catch{self.error=error.localizedDescription}}
    private func processPending(){
        guard let shot=pending else{return};pending=nil;processing=true
        Task { @MainActor in
            let suggestions=await Task.detached(priority:.userInitiated){Recognizer.inspect(shot.exposure.image,kind:shot.kind)}.value
            do{fitting=try library.attach(shot.exposure,kind:shot.kind,to:fitting,suggestions:suggestions);review=fitting.photos[shot.kind.rawValue]}catch{self.error=error.localizedDescription}
            processing=false
        }
    }
}
struct BasicForm:View {
    let onSave:(Fitting)throws->Void
    @State private var draft:Fitting
    @State private var error:String?
    @Environment(\.dismiss) private var dismiss
    init(initial:Fitting,onSave:@escaping(Fitting)throws->Void){self.onSave=onSave;_draft=State(initialValue:initial)}
    var body:some View{
        NavigationStack{
            Form{
                Section("기록"){TextField("고객 별칭 / 테 모델",text:$draft.name).textInputAutocapitalization(.never)}
                Section("실측 테 치수 · mm"){
                    TextField("A · 렌즈 가로폭",text:$draft.a).keyboardType(.decimalPad)
                    TextField("DBL · 브리지",text:$draft.dbl).keyboardType(.decimalPad)
                    Text("실제 렌즈의 박싱 치수를 사용하세요. 사진만으로 절대 길이를 알 수 없어 크기 기준이 필요합니다.").font(.caption)
                }
                Section("근거리") {TextField("눈–화면 거리 · cm",text:$draft.nearCM).keyboardType(.decimalPad)}
                Section("메모"){TextEditor(text:$draft.notes).frame(minHeight:140)}
                if let error=error{Text(error).foregroundStyle(.orange)}
            }.navigationTitle("기본정보")
                .toolbar{
                    ToolbarItem(placement:.cancellationAction){Button("취소"){dismiss()}}
                    ToolbarItem(placement:.confirmationAction){Button("저장"){
                        if !draft.a.isEmpty && !(Fitting.number(draft.a).map{(30...80).contains($0)} ?? false){error="A는 30–80 mm 범위로 입력하세요.";return}
                        if !draft.dbl.isEmpty && !(Fitting.number(draft.dbl).map{(5...40).contains($0)} ?? false){error="DBL은 5–40 mm 범위로 입력하세요.";return}
                        guard let distance=Fitting.number(draft.nearCM),(15...100).contains(distance) else{error="근거리 거리는 15–100 cm 범위로 입력하세요.";return}
                        do{try onSave(draft);dismiss()}catch{self.error=error.localizedDescription}
                    }}
                }
        }.interactiveDismissDisabled()
    }
}
struct SharePanel:UIViewControllerRepresentable{
    let url:URL
    func makeUIViewController(context:Context)->UIActivityViewController{UIActivityViewController(activityItems:[url],applicationActivities:nil)}
    func updateUIViewController(_ vc:UIActivityViewController,context:Context){}
}
