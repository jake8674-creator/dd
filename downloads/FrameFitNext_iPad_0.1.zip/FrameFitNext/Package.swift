// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "FrameFitCore", products: [.library(name: "FrameFitCore", targets: ["FrameFitCore"])], targets: [.target(name: "FrameFitCore", path: "FrameFit.swiftpm/Sources/Core"), .testTarget(name: "FrameFitCoreTests", dependencies: ["FrameFitCore"])], swiftLanguageModes: [.v5])
