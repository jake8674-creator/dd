#!/usr/bin/env bash
set -euo pipefail
project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_root"
if command -v swift >/dev/null 2>&1; then
  swift_bin="$(command -v swift)"
else
  swift_bin=/workspace/toolchains/swift-6.0.3-RELEASE-ubuntu24.04/usr/bin/swift
fi
[[ -x "$swift_bin" ]] || { echo 'Install Swift 6 or run bash scripts/setup-cloud.sh'; exit 1; }
cache="$project_root/.build/cache"
mkdir -p "$cache/clang"
export CLANG_MODULE_CACHE_PATH="$cache/clang"
export SWIFT_MODULECACHE_PATH="$cache/clang"
"$swift_bin" test --jobs 4 --cache-path "$cache/swiftpm" --config-path "$cache/config" --security-path "$cache/security"
# Parse only: this does NOT type-check Apple APIs or build the iPad app.
"$(dirname "$swift_bin")/swiftc" -frontend -parse FrameFit.swiftpm/Sources/App/*.swift FrameFit.swiftpm/Sources/Core/*.swift
