#!/usr/bin/env bash
set -euo pipefail
# Installs a verified toolchain outside the project; no Apple SDK is installed.
base=/workspace/toolchains
release=swift-6.0.3-RELEASE-ubuntu24.04
archive="$base/swift-download/swift.tar.gz"
mkdir -p "$base/swift-download" "$base/gnupg"
chmod 700 "$base/gnupg"
if [[ ! -x "$base/$release/usr/bin/swift" ]]; then
  [[ "$(uname -s)" == Linux && "$(uname -m)" == x86_64 ]] || { echo 'This bootstrap requires Linux x86_64'; exit 1; }
  origin=https://download.swift.org/swift-6.0.3-release/ubuntu2404/swift-6.0.3-RELEASE
  [[ -f "$archive" ]] || curl -fL --retry 2 "$origin/$release.tar.gz" -o "$archive"
  [[ -f "$archive.sig" ]] || curl -fL --retry 2 "$origin/$release.tar.gz.sig" -o "$archive.sig"
  [[ -f "$base/swift-download/keys.asc" ]] || curl -fL --retry 2 https://raw.githubusercontent.com/swiftlang/swift-org-website/main/keys/all-keys.asc -o "$base/swift-download/keys.asc"
  gpg --homedir "$base/gnupg" --batch --no-autostart --import "$base/swift-download/keys.asc"
  gpg --homedir "$base/gnupg" --batch --no-autostart --status-fd 1 --verify "$archive.sig" "$archive" > "$base/swift-download/verification.txt"
  rg -q '^\[GNUPG:\] VALIDSIG 52BB7E3DE28A71BE22EC05FFEF80A866B47A981F ' "$base/swift-download/verification.txt"
  tar -xzf "$archive" -C "$base"
fi
"$base/$release/usr/bin/swift" --version
