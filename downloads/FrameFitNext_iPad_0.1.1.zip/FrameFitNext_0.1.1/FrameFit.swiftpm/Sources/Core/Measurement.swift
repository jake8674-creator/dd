import Foundation

struct Vec: Codable, Equatable {
    var x: Double
    var y: Double
    static func +(a: Self, b: Self) -> Self { .init(x: a.x+b.x, y: a.y+b.y) }
    static func -(a: Self, b: Self) -> Self { .init(x: a.x-b.x, y: a.y-b.y) }
    static func *(a: Self, b: Double) -> Self { .init(x: a.x*b, y: a.y*b) }
    var length: Double { hypot(x,y) }
    var finite: Bool { x.isFinite && y.isFinite }
    var unit: Self { length > 0 ? self * (1/length) : .init(x:0,y:0) }
    func dot(_ b: Self) -> Double { x*b.x+y*b.y }
}
enum ViewKind: String, Codable, CaseIterable, Identifiable {
    case front, right, left, top, near
    var id: String { rawValue }
    var title: String {
        switch self { case .front: return "원거리 정면"; case .right: return "오른쪽 측면"; case .left: return "왼쪽 측면"; case .top: return "위쪽"; case .near: return "근거리 정면" }
    }
    var isFront: Bool { self == .front || self == .near }
    var isSide: Bool { self == .right || self == .left }
    var instruction: String {
        switch self {
        case .front: return "고객은 먼 표적을 봅니다. 촬영자는 눈높이 정면에서 촬영하세요. 렌즈 좌우 크기가 같게 보이도록 맞추세요."
        case .near: return "실제 읽는 거리와 자세에서 촬영합니다. 전면 화면 중앙 글자를 보세요. 근거리 값은 별도 사진으로 계산합니다."
        case .right, .left: return "고객은 먼 표적을 계속 봅니다. 촬영자가 옆으로 이동해 눈높이에서 정확한 측면을 촬영하세요. 렌즈 후면 위·아래를 구별할 수 있어야 합니다."
        case .top: return "고객 머리는 그대로, 카메라를 위로 이동하세요. 좌우 렌즈 후면의 수평 단면을 내려다봅니다. 사진 아래쪽이 코, 왼쪽이 고객 오른쪽입니다."
        }
    }
    var required: [Anchor] {
        if isFront { return [.pupilR,.pupilL,.outerR,.innerR,.upperR,.lowerR,.innerL,.outerL,.upperL,.lowerL] }
        if isSide { return [.backTop,.backBottom,.cornea] }
        return [.outerR,.innerR,.innerL,.outerL]
    }
}
enum Anchor: String, Codable, CaseIterable, Identifiable {
    case pupilR,pupilL,glintR,glintL,outerR,innerR,upperR,lowerR,innerL,outerL,upperL,lowerL,backTop,backBottom,cornea
    var id: String { rawValue }
    var title: String {
        switch self {
        case .pupilR:return "R 동공 중심"; case .pupilL:return "L 동공 중심"
        case .glintR:return "R 각막 반사 후보"; case .glintL:return "L 각막 반사 후보"
        case .outerR:return "R 렌즈 귀쪽"; case .innerR:return "R 렌즈 코쪽"
        case .upperR:return "R 렌즈 최상단"; case .lowerR:return "R 렌즈 최하단"
        case .innerL:return "L 렌즈 코쪽"; case .outerL:return "L 렌즈 귀쪽"
        case .upperL:return "L 렌즈 최상단"; case .lowerL:return "L 렌즈 최하단"
        case .backTop:return "렌즈 후면 위"; case .backBottom:return "렌즈 후면 아래"; case .cornea:return "각막 꼭짓점"
        }
    }
}
struct Mark: Codable { var point: Vec; var automatic: Bool }
struct PhotoRecord: Codable, Identifiable {
    var id = UUID()
    var kind: ViewKind
    var filename: String
    var width: Double
    var height: Double
    var marks: [String:Mark] = [:]
    var gravity: Vec?
    var flashFired = false
    var confirmed = false
    var poseConfirmed = false
    var reviewNote = ""
    func pixel(_ key: Anchor) -> Vec? {
        guard let p=marks[key.rawValue]?.point, p.finite, (0...1).contains(p.x), (0...1).contains(p.y) else { return nil }
        return .init(x:p.x*width,y:p.y*height)
    }
}
struct Fitting: Codable, Identifiable {
    var id=UUID()
    var date=Date()
    var name=""
    var a=""
    var dbl=""
    var nearCM="40"
    var notes=""
    var side: ViewKind = .right
    var photos: [String:PhotoRecord] = [:]
    var kinds: [ViewKind] { [.front,side,.top,.near] }
    var title: String { name.isEmpty ? "새 피팅" : name }
    static func number(_ value:String) -> Double? {
        guard let n=Double(value.trimmingCharacters(in:.whitespacesAndNewlines).replacingOccurrences(of:",",with:".")),n.isFinite else{return nil};return n
    }
}
struct Reading: Identifiable {
    var id: String
    var label: String
    var value: Double?
    var unit: String
    var reason: String
    var formatted: String { value.map {String(format:"%.1f",$0)} ?? "—" }
}
enum Measure {
    static func validate(_ p: PhotoRecord) -> String? {
        guard p.width.isFinite,p.height.isFinite,p.width>0,p.height>0 else{return "사진 크기 오류"}
        guard p.confirmed,p.poseConfirmed else{return "기준점과 촬영 자세 확인 필요"}
        guard p.kind == .near || p.flashFired else{return "후면 플래시 발광 확인 필요"}
        guard p.kind.required.allSatisfy({p.pixel($0) != nil}) else{return "필수 기준점 누락"}
        return nil
    }
    static func front(_ s:Fitting,_ kind:ViewKind) -> [Reading] {
        let names=["양안 PD","R 중심거리","L 중심거리","R 피팅 높이","L 피팅 높이"]
        func empty(_ reason:String)->[Reading] {names.enumerated().map{Reading(id:kind.rawValue+String($0.offset),label:kind.title+" · "+$0.element,unit:"mm",reason:reason)}}
        guard kind.isFront else{return empty("정면 촬영 필요")}
        guard let p=s.photos[kind.rawValue] else{return empty("촬영 필요")}
        if let error=validate(p){return empty(error)}
        guard let a=Fitting.number(s.a),let dbl=Fitting.number(s.dbl),(30...80).contains(a),(5...40).contains(dbl) else{return empty("실측 A·DBL 입력 필요")}
        let pr=p.pixel(.pupilR)!,pl=p.pixel(.pupilL)!,ro=p.pixel(.outerR)!,ri=p.pixel(.innerR)!,li=p.pixel(.innerL)!,lo=p.pixel(.outerL)!
        let span=lo-ro,h=span.unit,d=Vec(x:-h.y,y:h.x)
        guard span.length > p.width*0.2,h.x>0.7 else{return empty("정면 방향·좌우 기준점 확인")}
        let wr=(ri-ro).dot(h),wl=(lo-li).dot(h),bridge=(li-ri).dot(h)
        guard wr>0,wl>0,bridge>0,min(wr,wl)/max(wr,wl)>=0.9 else{return empty("좌우 렌즈 비대칭 · 정면 재촬영")}
        // Independent dimensional consistency prevents a wrong inner boundary passing total-width calibration.
        let scale=(2*a+dbl)/span.length
        guard abs(wr*scale-a)<=a*0.1,abs(wl*scale-a)<=a*0.1,abs(bridge*scale-dbl)<=max(2,dbl*0.15) else{return empty("A·DBL과 렌즈 경계 비율 불일치")}
        let topR=p.pixel(.upperR)!,bottomR=p.pixel(.lowerR)!,topL=p.pixel(.upperL)!,bottomL=p.pixel(.lowerL)!
        guard (pr-ro).dot(h)>0,(ri-pr).dot(h)>0,(pl-li).dot(h)>0,(lo-pl).dot(h)>0,
              (pr-topR).dot(d)>0,(bottomR-pr).dot(d)>0,(pl-topL).dot(d)>0,(bottomL-pl).dot(d)>0 else{return empty("동공이 렌즈 경계 밖 · 기준점 확인")}
        guard abs((pl-pr).dot(d))*scale<4 else{return empty("눈높이 차이 큼 · 자세 확인")}
        let center=(ri+li)*0.5
        let values=[(pl-pr).dot(h)*scale,(center-pr).dot(h)*scale,(pl-center).dot(h)*scale,(bottomR-pr).dot(d)*scale,(bottomL-pl).dot(d)*scale]
        guard values.allSatisfy({$0.isFinite && $0>0}),(35...90).contains(values[0]) else{return empty("계산 범위 밖")}
        return names.enumerated().map { i,n in Reading(id:kind.rawValue+String(i),label:kind.title+" · "+n,value:values[i],unit:"mm",reason:i==1 || i==2 ? "테 중심 기준 · 해부학적 단안 PD 아님" : "사진 투영 추정 · 실측 A/DBL 보정") }
    }
    static func side(_ s:Fitting) -> [Reading] {
        var row=Reading(id:"tilt",label:s.side.title+" · 경사각",unit:"°",reason:"측면 촬영 필요")
        // Transparency and unknown RGB/depth correspondence cannot establish the posterior lens surface.
        let vertex=Reading(id:"vertex",label:"정점간거리",unit:"mm",reason:"투명 렌즈 후면의 깊이를 검증할 수 없어 계산 보류")
        guard let p=s.photos[s.side.rawValue] else{return [row,vertex]}
        if let e=validate(p){row.reason=e;return [row,vertex]}
        guard let g=p.gravity,g.finite,g.length>0.3 else{row.reason="중력 기준 없음 · 다시 촬영";return [row,vertex]}
        let t=p.pixel(.backTop)!,b=p.pixel(.backBottom)!,c=p.pixel(.cornea)!,down=g.unit
        var forward=Vec(x:down.y,y:-down.x)
        if ((t+b)*0.5-c).dot(forward)<0 {forward=forward * -1}
        let vertical=(b-t).dot(down),gap=((t+b)*0.5-c).dot(forward)
        guard vertical>p.height*0.03,gap>p.width*0.002,(c-t).dot(down)>=0,(b-c).dot(down)>=0 else{row.reason="렌즈 후면·각막 기준점 확인";return [row,vertex]}
        let degrees=atan2((t-b).dot(forward),vertical)*180/Double.pi
        guard degrees.isFinite,abs(degrees)<=40 else{row.reason="측면 각도 범위 밖";return [row,vertex]}
        row.value=degrees;row.reason="측면 투영 추정 · 렌즈 하단이 얼굴 쪽이면 +"
        return [row,vertex]
    }
    static func wrap(_ s:Fitting) -> [Reading] {
        var total=Reading(id:"wrap",label:"전체 감김각",unit:"°",reason:"위쪽 촬영 필요")
        var half=Reading(id:"halfWrap",label:"안면각 · 편측 평균",unit:"°",reason:"좌우 개별 눈의 각도 아님")
        guard let p=s.photos[ViewKind.top.rawValue] else{return [total,half]}
        if let e=validate(p){total.reason=e;return [total,half]}
        let a=p.pixel(.innerR)!-p.pixel(.outerR)!,b=p.pixel(.outerL)!-p.pixel(.innerL)!
        guard a.length>p.width*0.08,b.length>p.width*0.08,a.x>0,b.x>0 else{total.reason="렌즈 방향점 확인";return [total,half]}
        let angle=acos(max(-1,min(1,a.unit.dot(b.unit))))*180/Double.pi
        guard angle.isFinite,angle<=70 else{total.reason="촬영 자세·기준점 확인";return [total,half]}
        total.value=angle;total.reason="위쪽 2D 투영 추정 · 후면의 수평 방향 기준"
        half.value=angle/2
        return [total,half]
    }
    static func all(_ s:Fitting)->[Reading] {front(s,.front)+front(s,.near)+side(s)+wrap(s)}
}
