import UIKit
import Combine

@MainActor final class Library:ObservableObject {
    @Published private(set) var items:[Fitting]=[]
    @Published var problem:String?
    private let root:URL
    private var readable=true
    init(){
        root=FileManager.default.urls(for:.documentDirectory,in:.userDomainMask)[0].appendingPathComponent("FrameFitNext",isDirectory:true)
        do {
            try FileManager.default.createDirectory(at:root,withIntermediateDirectories:true)
            var url=root;var flags=URLResourceValues();flags.isExcludedFromBackup=true;try url.setResourceValues(flags)
            let index=root.appendingPathComponent("records.json")
            if FileManager.default.fileExists(atPath:index.path){items=try JSONDecoder().decode([Fitting].self,from:Data(contentsOf:index))}
        }catch{readable=false;problem="기록 읽기 실패. 원본 보호를 위해 저장을 중지했습니다: \(error.localizedDescription)"}
    }
    func save(_ fitting:Fitting)throws{
        guard readable else{throw StorageError.unreadable}
        var next=items
        if let i=next.firstIndex(where:{$0.id==fitting.id}){next[i]=fitting}else{next.insert(fitting,at:0)}
        try persist(next);items=next
    }
    func delete(_ fitting:Fitting)throws{
        guard readable else{throw StorageError.unreadable}
        let next=items.filter{$0.id != fitting.id};try persist(next);items=next
        let directory=root.appendingPathComponent(fitting.id.uuidString)
        if FileManager.default.fileExists(atPath:directory.path){try FileManager.default.removeItem(at:directory)}
    }
    private func persist(_ items:[Fitting])throws{try JSONEncoder().encode(items).write(to:root.appendingPathComponent("records.json"),options:[.atomic,.completeFileProtection])}
    func attach(_ exposure:Exposure,kind:ViewKind,to fitting:Fitting,suggestions:Suggestions)throws->Fitting{
        let directory=root.appendingPathComponent(fitting.id.uuidString,isDirectory:true)
        try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
        let name=fitting.id.uuidString+"/"+UUID().uuidString+".jpg"
        guard let data=exposure.image.jpegData(compressionQuality:0.97) else{throw StorageError.image}
        let url=root.appendingPathComponent(name)
        try data.write(to:url,options:[.atomic,.completeFileProtection])
        var next=fitting
        next.photos[kind.rawValue]=PhotoRecord(kind:kind,filename:name,width:exposure.image.size.width,height:exposure.image.size.height,marks:suggestions.marks,gravity:exposure.gravity,flashFired:exposure.flash,reviewNote:suggestions.note)
        do{try save(next)}catch{try? FileManager.default.removeItem(at:url);throw error}
        return next
    }
    func image(_ record:PhotoRecord)->UIImage?{UIImage(contentsOfFile:root.appendingPathComponent(record.filename).path)}
    func export(_ fitting:Fitting)throws->URL{
        func cell(_ s:String)->String{
            // Spreadsheet formula injection: user text is explicitly literal.
            let cleaned=["=","+","-","@","\t","\r"].contains(where:{s.hasPrefix($0)}) ? "'"+s : s
            return "\""+cleaned.replacingOccurrences(of:"\"",with:"\"\"")+"\""
        }
        var rows=[["FrameFit Next · 사진 투영 추정 / 실측 검증 전"],["기록",fitting.name],["A",fitting.a,"DBL",fitting.dbl],["근거리 cm",fitting.nearCM],["항목","값","단위","상태"]]
        for r in Measure.all(fitting){rows.append([r.label,r.value == nil ? "" : r.formatted,r.unit,r.reason])}
        rows.append(["메모",fitting.notes])
        let text="\u{FEFF}"+rows.map{$0.map(cell).joined(separator:",")}.joined(separator:"\r\n")
        let url=FileManager.default.temporaryDirectory.appendingPathComponent("FrameFit-\(UUID().uuidString).csv")
        try text.write(to:url,atomically:true,encoding:.utf8);return url
    }
    enum StorageError:LocalizedError {
        case unreadable,image
        var errorDescription:String?{self == .unreadable ? "기록을 읽지 못한 상태입니다. 원본 복구 후 다시 시도하세요." : "사진 인코딩 실패"}
    }
}
