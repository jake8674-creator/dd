import SwiftUI
import UIKit

@MainActor struct MarkerReview:View {
    let image:UIImage
    let onSave:(PhotoRecord)throws->Void
    @State var record:PhotoRecord
    @Environment(\.dismiss) private var dismiss
    @State private var selected:Anchor
    @State private var error:String?
    @State private var inspected:Set<Anchor>=[]
    @State private var showCandidates=false
    @State private var contours:[[Vec]]=[]
    init(image:UIImage,record:PhotoRecord,onSave:@escaping(PhotoRecord)throws->Void){self.image=image;self.onSave=onSave;_record=State(initialValue:record);_selected=State(initialValue:record.kind.required[0])}
    private var keys:[Anchor]{record.kind.required+(record.kind.isFront ? [.glintR,.glintL] : [])}
    var body:some View {
        NavigationStack {
            HStack(spacing:0){
                VStack {
                    Text("\(selected.title) · 사진을 탭하거나 끌어서 지정").font(.headline).padding(.top)
                    MarkerCanvas(image:image,record:$record,selected:selected,inspected:$inspected,showCandidates:showCandidates,contours:contours)

                }
                sidebar

            }.navigationTitle(record.kind.title).navigationBarTitleDisplayMode(.inline)
                .toolbar{ToolbarItem(placement:.cancellationAction){Button("취소"){dismiss()}}}
                .task {
                    // Snapshot main-actor UI state before entering the worker task.
                    let photo=image
                    let kind=record.kind
                    let result=await Task.detached(priority:.userInitiated){Recognizer.inspect(photo,kind:kind)}.value
                    guard !Task.isCancelled else{return}
                    contours=result.contours
                }
        }.preferredColorScheme(.dark).interactiveDismissDisabled()
    }
    private var sidebar:some View {
ScrollView {
                    VStack(alignment:.leading,spacing:16){
                        Text("기준점 확인").font(.title2.bold())
                        Text(record.reviewNote).font(.caption).foregroundStyle(.secondary)
                        Text("R/L은 고객 기준입니다. 테 바깥 테두리가 아니라 실제 렌즈 경계를 지정하세요.").font(.caption)
                        if let mark=record.marks[selected.rawValue],let crop=magnified(mark.point){
                            ZStack{Image(uiImage:crop).resizable().interpolation(.none).scaledToFit();Image(systemName:"plus").foregroundStyle(.red)}.frame(height:150).background(.black)
                        }
                        ForEach(keys){key in
                            Button{selected=key}label:{HStack{Image(systemName:inspected.contains(key) ? "checkmark.circle.fill" : (record.marks[key.rawValue] == nil ? "circle.dashed" : "circle"));Text(key.title);Spacer()}.padding(9).background(selected==key ? Color.teal.opacity(0.2) : Color.clear,in:RoundedRectangle(cornerRadius:8))}.buttonStyle(.plain)
                        }
                        Button("선택한 점 확인 → 다음"){
                            inspected.insert(selected)
                            if let i=keys.firstIndex(of:selected),i+1<keys.count{selected=keys[i+1]}
                        }.buttonStyle(.borderedProminent).disabled(record.marks[selected.rawValue]==nil)
                        Button("선택한 점 지우기",role:.destructive){record.marks.removeValue(forKey:selected.rawValue);inspected.remove(selected);record.confirmed=false}
                        Toggle("윤곽 후보 표시",isOn:$showCandidates)
                        Toggle("안내대로 촬영한 자세를 확인했습니다",isOn:$record.poseConfirmed)
                        Text("확인 \(inspected.intersection(Set(record.kind.required)).count)/\(record.kind.required.count) · 모든 필수점을 확인해야 결과가 계산됩니다.").font(.caption)
                        if let error=error{Text(error).foregroundStyle(.orange)}
                        Button("확인 완료 · 저장") {commit(true)}.buttonStyle(.borderedProminent).disabled(!record.poseConfirmed || !record.kind.required.allSatisfy{inspected.contains($0) && record.marks[$0.rawValue] != nil})
                        Button("미확인 상태로 중간 저장"){commit(false)}.buttonStyle(.bordered)
                    }.padding(20)
                }.frame(width:300).background(Color(white:0.1))
    }
    private func commit(_ confirmed:Bool){var next=record;next.confirmed=confirmed;do{try onSave(next);dismiss()}catch{self.error=error.localizedDescription}}
    private func magnified(_ p:Vec)->UIImage?{
        guard let cg=image.cgImage else{return nil}
        let half=60.0,rect=CGRect(x:p.x*Double(cg.width)-half,y:p.y*Double(cg.height)-half,width:half*2,height:half*2)
        // A full crop keeps the crosshair at the selected point; edges have no misleading shifted crop.
        guard rect.minX>=0,rect.minY>=0,rect.maxX<=Double(cg.width),rect.maxY<=Double(cg.height),let crop=cg.cropping(to:rect) else{return nil}
        return UIImage(cgImage:crop)
    }
}

@MainActor private struct MarkerCanvas:View {
    let image:UIImage
    @Binding var record:PhotoRecord
    let selected:Anchor
    @Binding var inspected:Set<Anchor>
    let showCandidates:Bool
    let contours:[[Vec]]
    private var keys:[Anchor]{record.kind.required+(record.kind.isFront ? [.glintR,.glintL] : [])}
    var body:some View {
GeometryReader{geo in
                        let scale=min(geo.size.width/image.size.width,geo.size.height/image.size.height)
                        let size=CGSize(width:image.size.width*scale,height:image.size.height*scale)
                        let origin=CGPoint(x:(geo.size.width-size.width)/2,y:(geo.size.height-size.height)/2)
                        ZStack(alignment:.topLeading){
                            Image(uiImage:image).resizable().frame(width:size.width,height:size.height).position(x:geo.size.width/2,y:geo.size.height/2)
                            if showCandidates {
                                Path{path in for contour in contours {guard let first=contour.first else{continue};path.move(to:CGPoint(x:origin.x+first.x*size.width,y:origin.y+first.y*size.height));for p in contour.dropFirst(){path.addLine(to:CGPoint(x:origin.x+p.x*size.width,y:origin.y+p.y*size.height))}}}.stroke(.cyan.opacity(0.5),lineWidth:1).allowsHitTesting(false)
                            }
                            ForEach(keys){key in
                                if let mark=record.marks[key.rawValue]{
                                    let p=mark.point
                                    ZStack{Circle().stroke(key==selected ? Color.white : (mark.automatic ? .orange : .mint),lineWidth:2).frame(width:key==selected ? 26 : 16,height:key==selected ? 26 : 16);Text("+").font(.system(size:16)).foregroundStyle(.white)}
                                        .position(x:origin.x+p.x*size.width,y:origin.y+p.y*size.height).allowsHitTesting(false)
                                }
                            }
                        }.contentShape(Rectangle()).gesture(DragGesture(minimumDistance:0).onChanged{value in
                            let p=Vec(x:(value.location.x-origin.x)/size.width,y:(value.location.y-origin.y)/size.height)
                            guard (0...1).contains(p.x),(0...1).contains(p.y) else{return}
                            record.marks[selected.rawValue]=Mark(point:p,automatic:false);record.confirmed=false;inspected.remove(selected)
                        })
                    }.background(.black)
    }
}
