import SwiftUI
import UIKit
import Combine
import AVFoundation
import CoreMotion
import ImageIO

struct Exposure {var image:UIImage;var gravity:Vec?;var flash:Bool}
final class Camera: NSObject,ObservableObject,AVCapturePhotoCaptureDelegate {
    let session=AVCaptureSession()
    private let queue=DispatchQueue(label:"framefit.capture")
    private let output=AVCapturePhotoOutput()
    private let motion=CMMotionManager()
    private var device:AVCaptureDevice?
    private var stopped=false
    private var callback:((Exposure)->Void)?
    private var savedBrightness:CGFloat?
    private var screen:UIScreen?
    private var gravity:Vec?
    private var pendingFlash:DispatchWorkItem?
    let front:Bool
    @Published var ready=false
    @Published var busy=false
    @Published var whiteFlash=false
    @Published var error:String?
    init(front:Bool){self.front=front;super.init()}
    func start(){
        motion.deviceMotionUpdateInterval=0.05
        if motion.isDeviceMotionAvailable {motion.startDeviceMotionUpdates()}
        AVCaptureDevice.requestAccess(for:.video){[weak self] allowed in
            guard let self=self else{return}
            guard allowed else{self.fail("설정에서 카메라 접근을 허용하세요.");return}
            self.queue.async {
                guard !self.stopped,self.device==nil else{return}
                guard let device=AVCaptureDevice.default(.builtInWideAngleCamera,for:.video,position:self.front ? .front : .back) else{self.fail("카메라를 사용할 수 없습니다.");return}
                do {
                    let input=try AVCaptureDeviceInput(device:device)
                    self.session.beginConfiguration()
                    self.session.sessionPreset = .photo
                    guard self.session.canAddInput(input),self.session.canAddOutput(self.output) else{self.session.commitConfiguration();self.fail("카메라 구성 실패");return}
                    self.session.addInput(input);self.session.addOutput(self.output)
                    self.output.maxPhotoQualityPrioritization = .quality
                    self.session.commitConfiguration()
                    self.device=device
                    if !self.front && (!device.hasFlash || !self.output.supportedFlashModes.contains(.on)) {self.fail("이 카메라는 후면 LED 플래시를 지원하지 않습니다.");return}
                    self.session.startRunning()
                    DispatchQueue.main.async {self.ready=true}
                } catch {self.fail(error.localizedDescription)}
            }
        }
    }
    func take(window:UIWindow?,completion:@escaping(Exposure)->Void){
        guard ready,!busy,let window=window,let scene=window.windowScene else{return}
        busy=true;error=nil;callback=completion
        let orientation=scene.interfaceOrientation
        if let g=motion.deviceMotion?.gravity {
            let p:Vec
            switch orientation {
            case .landscapeLeft:p=Vec(x:g.y,y:g.x)
            case .landscapeRight:p=Vec(x:-g.y,y:-g.x)
            case .portraitUpsideDown:p=Vec(x:-g.x,y:g.y)
            default:p=Vec(x:g.x,y:-g.y)
            }
            gravity=p.length>0.3 && p.y>0 ? p.unit : nil
        } else {gravity=nil}
        let video=AVCaptureVideoOrientation(rawValue:orientation.rawValue) ?? .portrait
        if front {
            screen=window.screen;savedBrightness=window.screen.brightness
            window.screen.brightness=1;whiteFlash=true
            let work=DispatchWorkItem{[weak self] in self?.shoot(video)}
            pendingFlash=work
            DispatchQueue.main.asyncAfter(deadline:.now()+0.6,execute:work)
        } else {shoot(video)}
    }
    private func shoot(_ orientation:AVCaptureVideoOrientation){
        queue.async {
            guard !self.stopped,self.session.isRunning else{self.fail("촬영이 중지되었습니다.");return}
            if let c=self.output.connection(with:.video) {
                if c.isVideoOrientationSupported {c.videoOrientation=orientation}
                if c.isVideoMirroringSupported {c.automaticallyAdjustsVideoMirroring=false;c.isVideoMirrored=false}
            }
            let settings=AVCapturePhotoSettings(format:[AVVideoCodecKey:AVVideoCodecType.jpeg])
            settings.photoQualityPrioritization = .quality
            if !self.front {
                guard self.device?.isFlashAvailable==true else{self.fail("플래시 준비 안 됨 · 잠시 뒤 다시 촬영하세요.");return}
                settings.flashMode = .on
            }
            self.output.capturePhoto(with:settings,delegate:self)
        }
    }
    func photoOutput(_ output:AVCapturePhotoOutput,didFinishProcessingPhoto photo:AVCapturePhoto,error:Error?){
        if let e=error {fail(e.localizedDescription);return}
        let exif=photo.metadata[kCGImagePropertyExifDictionary as String] as? [String:Any]
        let flags=(exif?[kCGImagePropertyExifFlash as String] as? NSNumber)?.intValue
        let fired=flags.map{($0 & 1) == 1} ?? false
        guard front || fired else{fail("후면 플래시 사용을 확인하지 못했습니다. 다시 촬영하세요.");return}
        guard let data=photo.fileDataRepresentation(),let original=UIImage(data:data) else{fail("사진을 읽을 수 없습니다.");return}
        // Render EXIF rotation exactly once. All detection and editor coordinates use this image.
        let size=original.size,ratio=min(1,3000/max(size.width,size.height))
        let target=CGSize(width:size.width*ratio,height:size.height*ratio)
        let format=UIGraphicsImageRendererFormat();format.scale=1;format.opaque=true
        let image=UIGraphicsImageRenderer(size:target,format:format).image{_ in original.draw(in:CGRect(origin:.zero,size:target))}
        DispatchQueue.main.async {
            self.restore()
            let action=self.callback;self.callback=nil;self.busy=false
            action?(Exposure(image:image,gravity:self.gravity,flash:fired))
        }
    }
    func photoOutput(_ output:AVCapturePhotoOutput,didFinishCaptureFor resolvedSettings:AVCaptureResolvedPhotoSettings,error:Error?){if let error=error{fail(error.localizedDescription)}}
    func restore(){pendingFlash?.cancel();pendingFlash=nil;whiteFlash=false;if let b=savedBrightness{screen?.brightness=b};savedBrightness=nil;screen=nil}
    func stop(){restore();callback=nil;motion.stopDeviceMotionUpdates();queue.async{self.stopped=true;if self.session.isRunning{self.session.stopRunning()}}}
    private func fail(_ message:String){DispatchQueue.main.async{self.restore();self.busy=false;self.error=message;self.callback=nil}}
}
final class PreviewSurface:UIView {
    override class var layerClass:AnyClass{AVCaptureVideoPreviewLayer.self}
    var preview:AVCaptureVideoPreviewLayer{layer as! AVCaptureVideoPreviewLayer}
    var attached:((UIWindow?)->Void)?
    override func didMoveToWindow(){super.didMoveToWindow();attached?(window)}
    override func layoutSubviews(){
        super.layoutSubviews()
        guard let o=window?.windowScene?.interfaceOrientation,let v=AVCaptureVideoOrientation(rawValue:o.rawValue),let c=preview.connection else{return}
        if c.isVideoOrientationSupported{c.videoOrientation=v}
        if c.isVideoMirroringSupported{c.automaticallyAdjustsVideoMirroring=false;c.isVideoMirrored=false}
    }
}
@MainActor struct CameraPreview:UIViewRepresentable {
    let session:AVCaptureSession
    let onWindow:(UIWindow?)->Void
    func makeUIView(context:Context)->PreviewSurface{let v=PreviewSurface();v.preview.session=session;v.preview.videoGravity = .resizeAspect;v.attached=onWindow;return v}
    func updateUIView(_ v:PreviewSurface,context:Context){v.setNeedsLayout()}
}
@MainActor struct CaptureScreen:View {
    let kind:ViewKind
    let nearCM:String
    let completion:(Exposure)->Void
    @StateObject private var camera:Camera
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var phase
    @State private var window:UIWindow?
    @State private var count:Int?
    @State private var countdown:Task<Void,Never>?
    init(kind:ViewKind,nearCM:String,completion:@escaping(Exposure)->Void){self.kind=kind;self.nearCM=nearCM;self.completion=completion;_camera=StateObject(wrappedValue:Camera(front:kind == .near))}
    var body:some View {
        ZStack {
            VStack(spacing:16){
                HStack{Button("닫기"){dismiss()};Spacer();Text(kind.title).font(.title2.bold());Spacer();Label(kind == .near ? "화면 플래시" : "LED 플래시",systemImage:"bolt.fill")}
                ZStack {
                    Color.black
                    CameraPreview(session:camera.session){w in DispatchQueue.main.async{window=w}}
                    if kind.isFront {RoundedRectangle(cornerRadius:80).stroke(.white.opacity(0.6),style:StrokeStyle(lineWidth:2,dash:[10])).frame(width:320,height:400).allowsHitTesting(false)}
                    if kind == .near {Text("이 글자를 편하게 봅니다\n눈–화면 거리 \(nearCM) cm").font(.title2).multilineTextAlignment(.center).padding().background(.black.opacity(0.7),in:RoundedRectangle(cornerRadius:12))}
                    if let count=count{Text("\(count)").font(.system(size:100,weight:.bold))}
                }.clipped()
                Text(kind.instruction).frame(maxWidth:.infinity,alignment:.leading)
                if let error=camera.error{Text(error).foregroundStyle(.orange)}
                Button("3초 후 촬영"){
                    countdown=Task { @MainActor in
                        for n in [3,2,1]{count=n;do{try await Task.sleep(nanoseconds:1_000_000_000)}catch{count=nil;return}}
                        count=nil;camera.take(window:window,completion:completion)
                    }
                }.buttonStyle(.borderedProminent).controlSize(.large).disabled(!camera.ready || camera.busy || count != nil || window == nil)
            }.padding(24)
            if camera.whiteFlash {
                Color.white.ignoresSafeArea()
                Text("여기를 보세요").foregroundStyle(.black).font(.title3)
            }
        }.foregroundStyle(.white).background(Color.black)
            .onAppear{camera.start()}.onDisappear{countdown?.cancel();camera.stop()}
            .onChange(of:phase){_,p in if p != .active{countdown?.cancel();count=nil;camera.restore();dismiss()}}
    }
}
