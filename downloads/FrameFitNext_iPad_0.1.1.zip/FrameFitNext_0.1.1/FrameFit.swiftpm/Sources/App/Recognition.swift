import UIKit
import Vision

struct Suggestions {
    var marks: [String:Mark] = [:]
    var contours: [[Vec]] = []
    var note = ""
}
enum Recognizer {
    static func inspect(_ image:UIImage, kind:ViewKind)->Suggestions {
        guard let cg=image.cgImage else{return Suggestions(note:"사진을 읽지 못했습니다")}
        var result=Suggestions()
        let faces=VNDetectFaceLandmarksRequest()
        let contours=VNDetectContoursRequest()
        contours.maximumImageDimension=1024
        contours.contrastAdjustment=1.4
        contours.detectsDarkOnLight=true
        do {
            try VNImageRequestHandler(cgImage:cg,orientation:.up).perform(kind.isFront ? [faces,contours] : [contours])
        } catch {return Suggestions(note:"자동 인식 실패 · 기준점을 직접 지정하세요")}
        if let observation=contours.results?.first {
            func visit(_ c:VNContour) {
                let pts=c.normalizedPoints.map{Vec(x:Double($0.x),y:1-Double($0.y))}
                if pts.count>=12 {result.contours.append(pts)}
                for child in c.childContours {visit(child)}
            }
            for c in observation.topLevelContours {visit(c)}
        }
        if !kind.isFront {
            result.note="윤곽선은 위치 안내용입니다. \(kind.isSide ? "렌즈 후면 위·아래와 각막 꼭짓점" : "각 렌즈 후면의 코쪽·귀쪽")을 직접 지정하세요."
            return result
        }
        guard let face=faces.results?.max(by:{$0.boundingBox.width*$0.boundingBox.height < $1.boundingBox.width*$1.boundingBox.height}),let landmarks=face.landmarks else {
            result.note="얼굴을 찾지 못했습니다. 정면·밝기·반사를 확인하거나 직접 지정하세요.";return result
        }
        func points(_ region:VNFaceLandmarkRegion2D?)->[Vec] {
            guard let region=region else{return []}
            return region.normalizedPoints.map{ p in Vec(x:face.boundingBox.minX+Double(p.x)*face.boundingBox.width,y:1-(face.boundingBox.minY+Double(p.y)*face.boundingBox.height)) }
        }
        func center(_ pts:[Vec])->Vec? {guard !pts.isEmpty else{return nil};return pts.reduce(Vec(x:0,y:0),+) * (1/Double(pts.count))}
        guard faces.results?.count == 1,abs(face.yaw?.doubleValue ?? 0)<0.15 else {
            result.note="얼굴이 여러 명이거나 정면에서 벗어났습니다. 한 명만 정면으로 다시 촬영하거나 기준점을 직접 지정하세요."
            return result
        }
        let eyeRegions=[points(landmarks.leftEye),points(landmarks.rightEye)].filter{!$0.isEmpty}.sorted{center($0)!.x<center($1)!.x}
        let pupils=[center(points(landmarks.leftPupil)),center(points(landmarks.rightPupil))].compactMap{$0}.sorted{$0.x<$1.x}
        if pupils.count==2 {
            result.marks[Anchor.pupilR.rawValue]=Mark(point:pupils[0],automatic:true)
            result.marks[Anchor.pupilL.rawValue]=Mark(point:pupils[1],automatic:true)
        }
        let eyes=eyeRegions.compactMap(center)
        if eyes.count==2 {
            if let pair=LensCandidates.pair(contours:result.contours,eyes:eyes,aspect:Double(cg.width)/Double(cg.height)) {
                for (i,box) in [pair.right,pair.left].enumerated() {
                    let keys:[Anchor]=i==0 ? [.outerR,.innerR,.upperR,.lowerR] : [.innerL,.outerL,.upperL,.lowerL]
                    let ps=[Vec(x:box.left,y:box.center.y),Vec(x:box.right,y:box.center.y),Vec(x:box.center.x,y:box.top),Vec(x:box.center.x,y:box.bottom)]
                    for (key,p) in zip(keys,ps){result.marks[key.rawValue]=Mark(point:p,automatic:true)}
                }
            }
            for i in 0..<2 {
                if let glint=brightSpot(cg,eye:eyes[i],eyeWidth:(eyes[1].x-eyes[0].x)*0.3) {
                    result.marks[(i==0 ? Anchor.glintR : .glintL).rawValue]=Mark(point:glint,automatic:true)
                }
            }
        }
        result.note="주황색은 자동 후보입니다. 테 외곽·렌즈 반사가 섞일 수 있으므로 실제 렌즈 경계와 동공을 확대 확인하세요. 반사 후보는 PD 계산에 사용하지 않습니다."
        return result
    }
    private static func brightSpot(_ image:CGImage,eye:Vec,eyeWidth:Double)->Vec? {
        let w=image.width,h=image.height
        let rect=CGRect(x:(eye.x-eyeWidth/2)*Double(w),y:(eye.y-eyeWidth/4)*Double(h),width:eyeWidth*Double(w),height:eyeWidth*Double(h)/2).integral.intersection(CGRect(x:0,y:0,width:w,height:h))
        guard !rect.isNull,let crop=image.cropping(to:rect) else{return nil}
        let cw=crop.width,ch=crop.height
        var bytes=[UInt8](repeating:0,count:cw*ch*4)
        let ok=bytes.withUnsafeMutableBytes { raw -> Bool in
            guard let ctx=CGContext(data:raw.baseAddress,width:cw,height:ch,bitsPerComponent:8,bytesPerRow:cw*4,space:CGColorSpaceCreateDeviceRGB(),bitmapInfo:CGImageAlphaInfo.premultipliedLast.rawValue) else{return false}
            ctx.translateBy(x:0,y:CGFloat(ch));ctx.scaleBy(x:1,y:-1)
            ctx.draw(crop,in:CGRect(x:0,y:0,width:cw,height:ch));return true
        }
        guard ok else{return nil}
        var spots:[Vec]=[]
        for y in 0..<ch {for x in 0..<cw {
            let k=(y*cw+x)*4
            if min(bytes[k],min(bytes[k+1],bytes[k+2]))>245 {spots.append(Vec(x:Double(x),y:Double(y)))}
        }}
        // Large saturated patches are often lens glare. Do not place a false center.
        guard !spots.isEmpty,spots.count<max(3,cw*ch/25) else{return nil}
        let p=spots.min{hypot($0.x-Double(cw)/2,$0.y-Double(ch)/2)<hypot($1.x-Double(cw)/2,$1.y-Double(ch)/2)}!
        return Vec(x:(rect.minX+p.x)/Double(w),y:(rect.minY+p.y)/Double(h))
    }
}
